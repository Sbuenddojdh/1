# Telegram_User_Number_Finder :
Find the phone number of any telegram users

# Installation :

## 1.First you need a telegram account.
## 2.Then Go to this website https://my.telegram.org/auth and create telegram api id and api hash
## Follow this video tutorials if you don't understand what i am speaking
## Video Tutorial : 
### https://youtu.be/HPlFRqjJtX4
## 3.Edit line 40 in the script and replace it with your telegram number
## 4.Edit line 41 and replace your api id and api hash 

# Usage :
## Enter the list of phone numbers in List.txt
## Now run the script .It will ask to enter the code .
## Code will be sent to your telegram account
## After it will ask phone number list .Then it will ask for username enter the username (victim uaername)

# Note : Make sure you disable Two factor authentication in your telegram account


# Requirements
-  Python 3.7+
- If any module is missing install using pip3 install missing module


## Happy Hacking :

![Happy Hacking](https://raw.githubusercontent.com/swagkarna/Telegram_User_Number_Finder/master/giphy.gif)


# Legal Disclaimer:

**Usage of  this tool for attacking targets without prior mutual consent is illegal. It's the end user's responsibility to obey all applicable local, state and federal laws. Developers assume no liability and are not responsible for any misuse or damage caused by this program.**
